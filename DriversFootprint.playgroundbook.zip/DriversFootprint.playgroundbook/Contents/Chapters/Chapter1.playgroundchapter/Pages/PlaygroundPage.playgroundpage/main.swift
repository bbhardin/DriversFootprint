//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import UIKit
import PlaygroundSupport
import SwiftUI

let viewController = UIHostingController(rootView: MainView())

PlaygroundPage.current.setLiveView(viewController)
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
/*:
 
 # Driver's Footprint
 ### This tool is designed to help you estimate your “footprint” on the climate from driving and find ways to reduce that impact. Click Run My Code to run the tool!
 
 # Some Things to Try
 
 ## To learn more about emissions, notice how much of a difference your changes make by modifying the parameters:
 + Gas/Diesel
 + Type of Driving (City, Combined, Highway)
 + Gas Mileage
 + Distance Driven
 
 # What Are Emissions?

 Your vehicle burns fuel in order to move you forward. The burning of fuel produces gases, the most notable one being Carbon Dioxide, CO₂, that scientists consider the leading contributor to the Greenhouse Effect and Global Warming.

 Since Earth is our home and we worry about hurting it, many individuals want to know what they can do to help reduce CO₂ in the atmosphere. One of the best ways to reduce your emissions is by reducing the amount of driving you do, choosing other methods of transportation, or considering more fuel-efficient or electric cars.
 
 Vehicle emissions can cause smog in cities. Smog is the prescence of gases trapped in the air usually due to poor ciruclation and can be harmful to breathe.
 
 ![Beijing Smog](Beijing_smog_comparison_August_2005.png)
 *Image of Beijing Smog from 2005*
 *Image source: https://commons.wikimedia.org/wiki/File:Beijing_smog_comparison_August_2005.png*
 
 
 # Acknowledgements
 
 Emissions estimates based on United States EPA estimates found at:
 
 https://www.epa.gov/energy/greenhouse-gases-equivalencies-calculator-calculations-and-references
 
 
 Information about cow emissions comes from:
 
 http://www.fao.org/3/a0701e/a0701e00.htm
 
 
 Tree icons courtesy of:
 
 https://iconpacks.net/?utm_source=link-attribution&utm_content=1578
 
 
 Estimated electric car efficiency based on:
 
 https://avt.inl.gov/sites/default/files/pdf/fsev/costs.pdf
 
 
 */

