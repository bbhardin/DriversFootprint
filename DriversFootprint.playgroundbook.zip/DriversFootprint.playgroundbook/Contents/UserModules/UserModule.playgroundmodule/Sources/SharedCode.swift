//
//  See LICENSE folder for this template’s licensing information.
//
//  Source code for this playground!
//

import UIKit
import PlaygroundSupport
import SwiftUI
import SpriteKit
import ARKit
import RealityKit

let definedRadius : CGFloat = 15

struct Vehicle {
    var highwayMPG : Float = 0
    var cityMPG : Float = 0
    var combinedMPG : Float = 0
    var make = ""
    var model = ""
    var year : Int = 0
    var fuelType : FuelType = FuelType.gas
    
    init(highwayMPG: Float, cityMPG: Float, combinedMPG: Float, make: String, model: String, year:Int, fuelType:FuelType) {
        self.highwayMPG = highwayMPG
        self.cityMPG = cityMPG
        self.combinedMPG = combinedMPG
        self.make = make
        self.model = model
        self.year = year
        self.fuelType = fuelType
    }
}

enum FuelType {
    case gas
    case diesel
}

struct StandardTextField : ViewModifier {
    func body(content: Content) -> some View {
        return content
            .padding()
            .background(Color(UIColor.systemGray6))
            .cornerRadius(definedRadius)
            .foregroundColor(Color(UIColor.label))
    }
}

struct StandardButton : ViewModifier {
    func body(content: Content) -> some View {
        return content
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .cornerRadius(definedRadius)
    }
}

//  struct StandardLabel : ViewModifier {
//      func body(content: Content) -> some View {
//          return content
//          //.foregroundColor(Color(UIColor.label))
//      }
//  }

//  struct AboutView : View {
//      var body: some View {
//          VStack {
//              Text("These calculations are based on United States Environmental Protection Agency (EPA) estimates.").modifier(StandardLabel()).multilineTextAlignment(.leading)
//              Text("All calculations are merely rough estimates and are not to be taken as a literal representation of your carbon footprint.").modifier(StandardLabel()).multilineTextAlignment(.leading)
//          }.navigationBarTitle(Text(""), displayMode: .inline)
//          .navigationBarItems(leading: Text("About These Calculations").foregroundColor(.green).font(.system(size: 34, weight: .medium, design: .rounded))/*, trailing: Image(systemName: "leaf.fill").imageScale(.large).padding().foregroundColor(.green)*/)
//      }
//  }

class TreeScene : SKScene {
    //https://iconpacks.net/?utm_source=link-attribution&utm_content=1578
    override func didMove(to view: SKView) {
        self.backgroundColor = .clear
        view.allowsTransparency = true
        view.isOpaque = true
        view.backgroundColor = SKColor.clear.withAlphaComponent(0.0)
        var trees : [SKSpriteNode] = [SKSpriteNode()]
        for _ in 0...180 {
            let tree = SKSpriteNode(imageNamed: "tree.png")
            tree.size = CGSize(width: 25, height: 25)
            var weight = Int.random(in: 1..<3)
            let xPos : CGFloat = CGFloat.random(in: 0...frame.maxX)
            var yPos : CGFloat = 0.0
            if (abs(xPos - frame.midX) <= 50) {
                weight = Int.random(in: 1..<3)
                if (weight == 1) {
                    yPos = CGFloat.random(in: 15...frame.midY - 35)
                } else {
                    yPos = CGFloat.random(in: frame.midY + 25...frame.maxY - 15)
                }
            } else {
                yPos = CGFloat.random(in: 15...frame.maxY - 15)
            }
            
            tree.position = CGPoint(x: xPos, y: yPos)
            tree.physicsBody?.affectedByGravity = false
            addChild(tree)
            trees.append(tree)
        }
    }
}
class CowScene : SKScene {
    override func didMove(to view: SKView) {
        self.backgroundColor = .clear
        view.allowsTransparency = true
        view.isOpaque = true
        view.backgroundColor = SKColor.clear.withAlphaComponent(0.0)
        var cows : [SKLabelNode] = [SKLabelNode()]
        for _ in 0...50 {
            let cow = SKLabelNode()
            let range = ("🐄" as NSString).range(of: "🐄")
            let mutable = NSMutableAttributedString(string: "🐄", attributes: [.font: UIFont.systemFont(ofSize: 28)])
            mutable.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.systemGreen, range: range)
            cow.attributedText = mutable
            cow.fontName = "system"
            var weight = Int.random(in: 1..<3)
            let xPos : CGFloat = CGFloat.random(in: 0...frame.maxX)
            var yPos : CGFloat = 0.0
            if (abs(xPos - frame.midX) <= 50) {
                weight = Int.random(in: 1..<3)
                if (weight == 1) {
                    yPos = CGFloat.random(in: 15...frame.midY - 35)
                } else {
                    yPos = CGFloat.random(in: frame.midY + 25...frame.maxY - 15)
                }
            } else {
                yPos = CGFloat.random(in: 15...frame.maxY - 15)
            }
            
            cow.position = CGPoint(x: xPos, y: yPos)
            cow.physicsBody?.affectedByGravity = false
            addChild(cow)
            cows.append(cow)
        }
    }
}

class FloatingScene : SKScene {
    
    private var nodes : [SKLabelNode] = [SKLabelNode]()
    
    //      override func willMove(from view: SKView) {
    //          removeAllChildren()
    //          nodes.removeAll()
    //      }
    
    override func didMove(to view: SKView) {
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.friction = 0
        //physicsBody?.categoryBitMask = PhysicsCategori
        self.backgroundColor = .clear
        view.allowsTransparency = true
        view.isOpaque = true
        view.backgroundColor = SKColor.clear.withAlphaComponent(0.0)
        
        for _ in 0...180 {
            let node = SKLabelNode()
            let range = ("CO₂" as NSString).range(of: "CO₂")
            let mutable = NSMutableAttributedString(string: "CO₂", attributes: [.font: UIFont.preferredFont(forTextStyle: .headline)])
            mutable.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.systemGreen, range: range)
            node.physicsBody = SKPhysicsBody(circleOfRadius: 25 / 2)
            node.attributedText = mutable
            node.fontName = "system"
            node.fontColor = UIColor.green
            let xPos = CGFloat.random(in: 0...frame.maxX)
            let yPos = CGFloat.random(in: (frame.midY / 2)...frame.maxY)
            node.position = CGPoint(x: xPos, y: yPos)
            nodes.append(node)
            node.physicsBody?.affectedByGravity = false
            addChild(node)
            let xForce = Int.random(in: -5...5)
            let yForce = Int.random(in: 3...5)
            let force = SKAction.applyForce(CGVector(dx: xForce, dy: yForce) , duration: 0.1)
            node.run(force)
        }
    }
}

public struct MainView : View {
    
    @StateObject var nm = NumbersModel()
    
    public init() {
        
    }
    
    var floatingScene: SKScene {
        let scene = FloatingScene()
        scene.size = CGSize(width: 1000, height: 400)
        scene.scaleMode = .aspectFill
        return scene
    }
    
    public var body: some View {
        NavigationView {
            ZStack {
                VStack {
                    SpriteView(scene: floatingScene, options: [.allowsTransparency])
                        .frame(height: 400)
                        .ignoresSafeArea()
                    Spacer()
                }
                
                VStack {
                    Image(uiImage: UIImage(named: "gas-station.png")!)
                        .renderingMode(.template).resizable().scaledToFit().frame(width: 150, height: 150, alignment: .center).padding(.bottom, 20).foregroundColor(Color.gray)
                    Text("Driver's Footprint")
                        .font(.system(size: 34, weight: .medium, design: .rounded))
                        .fontWeight(.medium).padding(.bottom, 1)
                    Text("An app by Ben Hardin").font(.system(size: 15)).padding(.bottom, 20)
                    NavigationLink(destination: MyNavigationView(CalculateView())) { Text("Get Started") }.modifier(StandardButton())
                    
                }
            }
        }.environmentObject(nm).navigationViewStyle(StackNavigationViewStyle()).font(.system(size: 20, weight: .medium, design: .default)).navigationTitle("")
    }
    
}

/**
 * Holds all the variables
 */
class NumbersModel : ObservableObject {
    @Published var singleTrip : Float = 0.0
    @Published var yearlyEmissions : Float = 0.0
    @Published var semiSingle : Float = 0.0
    @Published var semiYearly : Float = 0.0
    @Published var busSingle : Float = 0.0
    @Published var busYearly : Float = 0.0
    @Published var miles : Float = 0.0
    @Published var electricSingleReductions : Float = 0.0
    @Published var electricYearlyReductions : Float = 0.0
    @Published var numCows : Int = 0
    @Published var semiString : String = ""
    @Published var busString : String = ""
    @Published var extraBusText : String  = ""
    @Published var electricPercent : String = ""
    
    @Published var trees : Int = 0
    
    func updateSingleTrip(singleTrip: Float) {
        self.singleTrip = singleTrip
    }
    
    func updateMiles(miles: Float) {
        self.miles = miles
    }
    
    func updateTrees(trees: Int) {
        self.trees = trees
    }
}
/*
 struct VehicleView : View {
 @State private var highwayMPG = String(Int(myCar.highwayMPG))
 @State private var cityMPG = String(Int(myCar.cityMPG))
 @State private var combinedMPG = String(Int(myCar.combinedMPG))
 @State private var fuel : FuelType = myCar.fuelType
 @State private var error = ""
 @State private var selectorState = 0
 var body: some View {
 VStack {
 Image(systemName: "car.circle.fill")
 .font(.system(size: 96))
 .padding(.bottom, 20)
 .foregroundColor(.green)
 HStack {
 Text("Enter Your Vehicle Details")
 .font(.system(size: 34, weight: .medium, design: .rounded))
 .multilineTextAlignment(.center)
 .foregroundColor(Color.gray)
 .padding(.bottom, 2)
 Spacer()
 }
 HStack {
 Text("City MPG").frame(width: 200, height: 25, alignment: .leading).modifier(StandardLabel())
 TextField("City MPG", text: $cityMPG).modifier(StandardTextField())
 }.padding(.bottom, 2)
 HStack {
 Text("Combined MPG").frame(width: 200, height: 25, alignment: .leading).modifier(StandardLabel())
 TextField("Combined MPG", text: $combinedMPG).modifier(StandardTextField())
 }.padding(.bottom, 2)
 HStack {
 Text("Highway MPG").frame(width: 200, height: 25, alignment: .leading).modifier(StandardLabel())
 TextField("Highway MPG", text: $highwayMPG).modifier(StandardTextField())
 }.padding(.bottom, 2)
 HStack {
 Text("Fuel Type").frame(width: 200, height: 25, alignment: .leading).modifier(StandardLabel())
 Picker(selection: $selectorState, label: Text("")) {
 Text("Gasoline").tag(0)
 Text("Diesel").tag(1)
 }
 .pickerStyle(SegmentedPickerStyle())
 }.padding(.bottom, 10)
 HStack {
 Spacer()
 Text("Unsure?").modifier(StandardLabel()).font(.system(size: 20))
 Button("Autofill") {
 cityMPG = "20"
 combinedMPG = "22"
 highwayMPG = "25"
 }.font(.system(size: 20))
 }
 
 Button("Save Vehicle") {
 let cityNum = Float(cityMPG)
 let combinedNum = Float(combinedMPG)
 let highwayNum = Float(highwayMPG)
 if (cityNum == nil || combinedNum == nil || highwayNum == nil) {
 error = "Error: Please ensure your inputs are numbers"
 } else {
 var ftype : FuelType = FuelType.gas
 if (selectorState == 1) {
 ftype = FuelType.diesel
 }
 myCar = Vehicle(highwayMPG: highwayNum!, cityMPG: cityNum!, combinedMPG: combinedNum!, make: "", model: "", year: 0, fuelType: ftype)
 }
 }.padding().background(Color.green).cornerRadius(definedRadius).foregroundColor(.white)
 }.padding()
 }
 }
 */

struct CalculateView : View {
    @State private var miles  = ""
    @State private var driveTypeSelectorState = 1
    @State private var fuelTypeSelectorState = 0
    @State private var error = ""
    @State private var showReport = false
    //      @State private var oneTrip : Float = 0.0
    //      @State private var yearly : Float = 0.0
    
    @State private var cityMPG = ""
    @State private var combinedMPG = ""
    @State private var highwayMPG = ""
    
    @EnvironmentObject var nm: NumbersModel
    
    init() {
        UINavigationBar.appearance().backgroundColor = UIColor.systemGray6
    }
    
    var body : some View {
        ScrollView {
            
            
            ZStack {
                //                  VStack {
                //
                //                      Spacer()
                //                  }
                VStack {
                    //Spacer(minLength: 75)
                    Image(systemName: "car.circle.fill")
                        .font(.system(size: 96))
                        .padding(.bottom, 20)
                        .foregroundColor(.green)
                    HStack {
                        Text("First, let's get some information")
                            .font(.system(size: 32, weight: .medium, design: .rounded))
                            .foregroundColor(Color.gray)
                            .multilineTextAlignment(.leading)
                            .lineLimit(4)
                        Spacer()
                    }.padding(.bottom, 10)
                    HStack {
                        Text("Miles driven one-way to work or school")
                            .multilineTextAlignment(.leading)
                        Spacer()
                    }
                    TextField("Miles", text: $miles).modifier(StandardTextField())
                    HStack {
                        Text("Type of Driving").multilineTextAlignment(.leading)
                        Spacer()
                    }
                    Picker(selection: $driveTypeSelectorState, label: Text("")) {
                        Text("City").tag(0)
                        Text("Combined").tag(1)
                        Text("Highway").tag(2)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    Group {
                        HStack {
                            Text("Enter Your Vehicle Details")
                                .font(.system(size: 28, weight: .medium, design: .default))
                                .multilineTextAlignment(.center)
                                .foregroundColor(Color.gray)
                                .multilineTextAlignment(.leading)
                                .lineLimit(4)
                                .padding(.bottom, 2)
                            Spacer()
                        }
                        HStack {
                            Text("City MPG").frame(width: 200, height: 25, alignment: .leading)
                            TextField("City MPG", text: $cityMPG).modifier(StandardTextField())
                        }.padding(.bottom, 2)
                        HStack {
                            Text("Combined MPG").frame(width: 200, height: 25, alignment: .leading)
                            TextField("Combined MPG", text: $combinedMPG).modifier(StandardTextField())
                        }.padding(.bottom, 2)
                        HStack {
                            Text("Highway MPG").frame(width: 200, height: 25, alignment: .leading)
                            TextField("Highway MPG", text: $highwayMPG).modifier(StandardTextField())
                        }.padding(.bottom, 2)
                        HStack {
                            Text("Fuel Type").frame(width: 200, height: 25, alignment: .leading)
                            Picker(selection: $fuelTypeSelectorState, label: Text("")) {
                                Text("Gasoline").tag(0)
                                Text("Diesel").tag(1)
                            }
                            .pickerStyle(SegmentedPickerStyle())
                        }.padding(.bottom, 10)
                        HStack {
                            Spacer()
                            Text("Unsure?").font(.system(size: 20))
                            Button("Autofill") {
                                cityMPG = "20"
                                combinedMPG = "22"
                                highwayMPG = "25"
                            }.font(.system(size: 20))
                        }
                    }
                    NavigationLink(destination: MyNavigationView(StatisticView()), isActive: $showReport) { Text("") }
                    Button("Get My Report") {
                        self.disabled(true)
                        let milesNum = Float(miles)
                        let highwayNum = Float(highwayMPG)
                        let cityNum = Float(cityMPG)
                        let combinedNum = Float(combinedMPG)
                        if (milesNum == nil || milesNum! < 0
                                || highwayNum == nil || highwayNum! < 0
                                || cityNum == nil || cityNum! < 0
                                || combinedNum == nil || combinedNum! < 0) {
                            error = "Error: Please enter a valid number"
                            self.disabled(false)
                        } else {
                            
                            var fuelType : FuelType = FuelType.gas
                            if (fuelTypeSelectorState == 1) {
                                fuelType = FuelType.diesel
                            }
                            let myCar = Vehicle(highwayMPG: highwayNum!, cityMPG: cityNum!, combinedMPG: combinedNum!, make: "", model: "", year: 0, fuelType: fuelType)
                            
                            // Calculate emissions for car
                            (nm.singleTrip, nm.yearlyEmissions) = calculateEmissionsForVehicle(miles: milesNum!, driveType: driveTypeSelectorState, vehicle: myCar)
                            
                            // Calculate emissions for electric car
                            let (singleReductions, yearlyReductions) = calculateEmissionsReductions(miles: milesNum!)
                            nm.electricSingleReductions = singleReductions
                            nm.electricYearlyReductions = yearlyReductions
                            
                            // Calculate emissions for bus
                            let bus = Vehicle(highwayMPG: 6, cityMPG: 5, combinedMPG: 5, make: "", model: "", year: 0, fuelType: FuelType.diesel)
                            (nm.busSingle, nm.busYearly) = calculateEmissionsForVehicle(miles: milesNum!, driveType: 1, vehicle: bus)
                            
                            // Calculate emissions for semi truck
                            let semi = Vehicle(highwayMPG: 7, cityMPG: 7, combinedMPG: 7, make: "", model: "", year: 0, fuelType: FuelType.diesel)
                            (nm.semiSingle, nm.semiYearly) = calculateEmissionsForVehicle(miles: milesNum!, driveType: 1, vehicle: semi)
                            
                            // Tree calculations
                            // 0.060 metric ton CO2 per urban tree planted for 10 years!!!
                            let metricTonsConsumedPerYear : Double = 0.060 / 10.0
                            let floatTrees = ceil(Double(nm.yearlyEmissions) / metricTonsConsumedPerYear)
                            nm.updateTrees(trees: Int(floatTrees))
                            
                            // Cow calculations
                            // 10 cows = 1 metric ton of methane
                            // 1 ton of methane * 23 = effect of 1 ton of CO2
                            let tonsMethane = nm.yearlyEmissions / 23.0
                            let cow = tonsMethane * 10 * 1200 // 1200 for number of burgers
                            let intCow = Int(ceil(cow))
                            nm.numCows = intCow
                            
                            // Semi String
                            if (nm.semiSingle > nm.singleTrip) {
                                let times = nm.semiSingle / nm.singleTrip
                                nm.semiString = "A semi truck outputs \(String(format: "%.2f", times)) times more CO₂ than your vehicle."
                            } else {
                                let times = nm.singleTrip / nm.semiSingle
                                nm.semiString = "Your vehicle outputs \(String(format: "%.2f", times)) times more CO₂ than a semi truck. 😬"
                            }
                            
                            // Bus string
                            if (nm.busSingle > nm.singleTrip * 30) {
                                let times = nm.busSingle / nm.singleTrip * 30
                                nm.busString = "A city bus outputs \(String(format: "%.1f", times)) times more CO₂ than your vehicle."
                                nm.extraBusText = ""
                            } else {
                                let times = nm.singleTrip / nm.busSingle * 30
                                nm.busString = "Your vehicle outputs \(String(format: "%.1f", times)) times more CO₂ than a city bus."
                                nm.extraBusText = "Taking the bus is an excellent way to reduce emissions, especially as more buses are becoming hybrid or electric."
                            }
                            
                            let percent =  100.0 - ( nm.electricSingleReductions  / nm.singleTrip) * 100.0
                            nm.electricPercent = String(format: "%.1f", percent)
                            error = ""
                            self.disabled(false)
                            showReport = true
                        }
                    }.modifier(StandardButton()).padding(.bottom, 20)
                    Text("\(error)").foregroundColor(.red)
                }.fixedSize(horizontal: false, vertical: true).padding()
            }.navigationBarTitle(Text(""), displayMode: .inline)
        }
    }
}
//#-hidden-code

struct StatisticView : View {
    //      @State private var error = ""
    //      @State private var showingTreeInfo = false
    //      @State private var showingCowInfo = false
    //
    //
    @EnvironmentObject var numbersModel : NumbersModel
    
    var body: some View {
        ScrollView {
            VStack {
                YourEmissionsView(numbersModel: numbersModel)
                YourCompareView(numbersModel: numbersModel)
                HowManyTrees()
                HowManyCows()
                Text("Disclaimer: These are only estimations and are not meant to be taken as exact measurements. This is only for demonstration purposes.").font(.system(size: 11)).fixedSize(horizontal: false, vertical: true).padding(.top, 5)
            }.padding().navigationBarTitle(Text(""), displayMode: .inline).navigationBarItems(leading: Text("Your Report").foregroundColor(.green).font(.system(size: 34, weight: .medium, design: .rounded)), trailing: Image(systemName: "leaf.fill").imageScale(.large).padding().foregroundColor(.green))
        }
        
    }
}

struct MyNavigationView<Content: View>: View {
    let build: () -> Content
    init(_ build: @autoclosure @escaping () -> Content) {
        self.build = build
    }
    var body: Content {
        build()
    }
}


struct YourEmissionsView : View {
    
    @ObservedObject var numbersModel : NumbersModel
    
    var body : some View {
        VStack {
            Spacer(minLength: 20)
            HStack {
                Text("Your Emissions")
                    .font(.system(size: 34, weight: .medium, design: .rounded))
                    .foregroundColor(Color.gray)
                Spacer()
            }.padding(.bottom, 10)
            HStack {
                Text("\(numbersModel.singleTrip)").font(.system(size: 26, weight: .medium))
                Spacer()
                Text("Round-Trip Commute")
            }.padding(.bottom, 2).padding(.leading, 5).padding(.trailing, 5)
            HStack {
                Text(String(numbersModel.yearlyEmissions)).font(.system(size: 26, weight: .medium))
                Spacer()
                Text("Yearly")
            }.padding(.bottom, 5).padding(.leading, 5).padding(.trailing, 5)
            HStack {
                Text("Metric tons of CO₂!").padding(.bottom, 10)
                Spacer()
            }.padding(.leading, 5).padding(.trailing, 5)
            HStack {
                Spacer()
                Text("1 metric ton = 2204.62 pounds").font(.system(size: 18))
            }
        }
    }
}

struct YourCompareView : View {
    @ObservedObject var numbersModel : NumbersModel
    
    var body : some View {
        HStack {
            Text("How Your Emissions Compare").multilineTextAlignment(.leading).foregroundColor(.gray).padding(.top, 10).padding(.bottom, 5).font(.system(size: 28, weight: .medium, design: .default))
            Spacer()
        }.padding(.top, 20)
        Group{
            HStack {
                VStack {
                    Image(systemName: "bicycle").frame(width: 50)
                    Spacer()
                }.frame(width: 50)
                VStack {
                    HStack {
                        Text("Bicycle")
                        Spacer()
                    }.padding(.bottom, 5)
                    HStack {
                        Text("0g CO₂").font(.system(size: 34, weight: .medium, design: .rounded))
                        Text("(Well... excluding your heavy breathing 😜)").font(.system(size: 15))
                        Spacer()
                    }
                }
            }
            HStack {
                VStack {
                    Image(systemName: "bolt.car.fill")
                    Spacer()
                }.frame(width: 50)
                VStack {
                    HStack {
                        Text("Electric Car")
                        Spacer()
                    }.padding(.bottom, 5)
                    HStack {
                        Text("An electric car would reduce your yearly emissions by: ").multilineTextAlignment(.leading).lineLimit(4).padding(.bottom, 5).fixedSize(horizontal: false, vertical: true).font(.system(size: 20))
                        Spacer()
                        Text("\(numbersModel.electricPercent)%").font(.system(size: 34, weight: .medium, design: .rounded)).padding(.trailing, 5).multilineTextAlignment(.leading)
                    }
                }
            }
            HStack {
                VStack {
                    Image(systemName: "bus.fill").frame(width: 50)
                    Spacer()
                }.frame(width: 50)
                VStack {
                    HStack {
                        Text("Bus")
                        Spacer()
                    }.padding(.bottom, 5)
                    HStack {
                        Text("\(numbersModel.busString)").fixedSize(horizontal: false, vertical: true).lineLimit(4).font(.system(size: 20))
                        Spacer()
                    }.padding(.bottom, 2)
                    HStack {
                        Text("\(numbersModel.extraBusText)").font(.system(size: 20)).fixedSize(horizontal: false, vertical: true)
                        Spacer()
                    }
                }
            }
            
            HStack {
                VStack {
                    Image(systemName: "shippingbox.fill")
                    Spacer()
                }.frame(width: 50)
                VStack {
                    HStack {
                        Text("Semi Truck")
                        Spacer()
                    }.padding(.bottom, 5)
                    HStack {
                        Text("\(numbersModel.semiString)").lineLimit(4).fixedSize(horizontal: false, vertical: true).font(.system(size: 20))
                        Spacer()
                    }
                }
            }
            
        }.padding(.bottom, 10)
    }
}

struct HowManyTrees : View {
    @EnvironmentObject var numbersModel : NumbersModel
    
    var treeScene: SKScene {
        let scene = TreeScene()
        scene.size = CGSize(width: 1000, height: 200)
        scene.scaleMode = .aspectFill
        return scene
    }
    
    var body : some View {
        VStack {
            HStack {
                Text("How Many Trees Would It Take").multilineTextAlignment(.leading).foregroundColor(.gray).padding(.top, 10).padding(.bottom, 5).font(.system(size: 28, weight: .medium, design: .default))
                Spacer()
                NavigationLink(destination: TreeInfo()) {
                    Image(systemName: "info.circle")
                }
            }.padding(.top, 20)
            Text("Number of trees you would have to plant in order to offset a year of driving:").font(.system(size: 20)).fixedSize(horizontal: false, vertical: true)
            ZStack {
                SpriteView(scene: treeScene, options: [.allowsTransparency])
                    .frame(height: 200)
                    .ignoresSafeArea()
                Text("\(numbersModel.trees)").font(.system(size: 40, weight: .bold, design: .rounded)).padding(.top, 5)
                    .shadow(color: Color.white.opacity(10.0), radius: 15)
            }
            Text("While planting trees is awesome, you simply have to reduce your driving to cut emissions.").lineLimit(5).fixedSize(horizontal: false, vertical: true).font(.system(size: 20))
        }.padding()
    }
}
//#-end-hidden-code

struct HowManyCows : View {
    @EnvironmentObject var numbersModel : NumbersModel
    var cowScene: SKScene {
        let scene = CowScene()
        scene.size = CGSize(width: 1000, height: 200)
        scene.scaleMode = .aspectFill
        return scene
    }
    
    var body : some View {
        VStack {
            HStack {
                Text("How Many Cows Would It Take").multilineTextAlignment(.leading).foregroundColor(.gray).padding(.top, 10).padding(.bottom, 5).font(.system(size: 28, weight: .medium, design: .default))
                Spacer()
                NavigationLink(destination: CowInfo()) {
                    Image(systemName: "info.circle")
                }
            }.padding(.top, 20).fixedSize(horizontal: false, vertical: true)
            Text("Number of burgers you would have to avoid eating in order to offset a year of driving:").font(.system(size: 20)).fixedSize(horizontal: false, vertical: true)
            ZStack {
                SpriteView(scene: cowScene, options: [.allowsTransparency])
                    .frame(height: 200)
                    .ignoresSafeArea()
                Text("\(numbersModel.numCows)").font(.system(size: 40, weight: .bold, design: .rounded)).padding(.top, 5)
                    .shadow(color: Color.white.opacity(10.0), radius: 15)
            }
            HStack {
                Text("You probably don't even eat that many burgers in a year... Reducing your beef intake is great, but it's not enough to offset driving.")
                    .lineLimit(5).font(.system(size: 20)).multilineTextAlignment(.leading).padding(.bottom, 5)
                Spacer()
            }.fixedSize(horizontal: false, vertical: true)
        }.padding()
    }
}


func calculateEmissionsReductions(miles: Float) -> (Float, Float) {
    // Miles * 2 for round trip divided by 3 for kWh/mile
    let kWh = miles / 3.3
    // 7.07 × 10-4 metric tons CO2/kWh
    let tonsReduced = 0.000507 * kWh * 2.0
    let yearly = tonsReduced * 50 * 5
    return (tonsReduced, yearly)
}

func calculateEmissionsForVehicle(miles: Float, driveType: Int, vehicle: Vehicle) -> (Float, Float) {
    var CO2Modifier : Float = 0.0
    if (vehicle.fuelType == FuelType.gas) {
        // Gas vehicle
        CO2Modifier = 0.008887 // metric tons per gallon of gas
    } else {
        // Diesel vehicle
        CO2Modifier = 0.010180 // metric tons per gallon of diesel
    }
    
    var mpg : Float = 0.0
    switch driveType {
    case 0:
        mpg = Float(vehicle.cityMPG) // City driving
        break
    case 1:
        mpg = Float(vehicle.combinedMPG) // Combined driving
        break
    case 2:
        mpg = Float(vehicle.highwayMPG) // Highway driving
        break
    default:
        break;
    }
    
    let gallonsUsed = miles / mpg
    let metricTons = gallonsUsed * CO2Modifier * 2.0
    let yearly = metricTons * 50 * 5
    let roundTrip = metricTons
    
    return (roundTrip, yearly)
}

struct TreeInfo : View {
    
    var body : some View {
        VStack {
            Image(uiImage: UIImage(named: "tree.png")!)
                .renderingMode(.original).resizable().scaledToFit().frame(width: 150, height: 150, alignment: .center)
                .padding(.bottom, 20)
            HStack {
                Text("Trees take in carbon dioxide from the air in order to grow! Planting trees helps remove polution, and tree roots also help prevent soil erosion. ").lineLimit(10)
                Spacer()
            }.padding(.bottom, 2)
            HStack {
                Text("However, trees can only absorb so much CO₂. Thus they're not able to consume everything emitted from driving.").lineLimit(10)
                Spacer()
            }
        }.navigationBarTitle(Text(""), displayMode: .inline).navigationBarItems(leading: Text("Why Trees?").foregroundColor(.green).font(.system(size: 34, weight: .medium, design: .rounded)).foregroundColor(.green)).padding()
    }
}

struct CowInfo : View {
    
    var body : some View {
        VStack {
            Text("🐄").font(.system(size: 96))
            HStack {
                Text("Cows don't release CO₂, but they release Methane which is estimated to be 23 times worse for the environment.").lineLimit(5)
                Spacer()
            }.padding(.bottom, 2)
            HStack {
                Text("If you didn't want to reduce your driving emissions, you could reduce your emissions by eating less beef... but you probably saw on the last page that cutting back beef consumption won't make up for any sizeable amount of driving.").lineLimit(10)
                Spacer()
            }
        }.navigationBarTitle(Text(""), displayMode: .inline).navigationBarItems(leading: Text("Why Cows?").foregroundColor(.green).font(.system(size: 34, weight: .medium, design: .rounded)).foregroundColor(.green)).padding()
    }
}
